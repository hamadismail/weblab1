package greenChat;

import javax.swing.*;
import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

//import static greenChat.Client.*;

public class ClientHandler extends Thread {

    final Socket com_tunnel;
    final DataInputStream dis_tunnel;
    final DataOutputStream dos_tunnel;

    public ClientHandler(Socket comTunnel, DataInputStream disTunnel, DataOutputStream dosTunnel)
    {
        this.com_tunnel = comTunnel;
        this.dis_tunnel = disTunnel;
        this.dos_tunnel = dosTunnel;
    }
//        String msg = disTunnel.readUTF();
//        JPanel panel = formatLabel(msg);
//
//        JPanel left = new JPanel(new BorderLayout());
//        left.add(panel, BorderLayout.LINE_START);
//        vertical.add(left);
//        f.validate();

        public void run () {
            try {
                while(true) {
                    String msg = dis_tunnel.readUTF();
                    JPanel panel = Server.formatLabel(msg);

                    JPanel left = new JPanel(new BorderLayout());
                    left.add(panel, BorderLayout.LINE_START);
                    Server.vertical.add(left);
                    Server.f.validate();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
